#/bin/bash

#set catalina opts
CATALINA_BASE=/node
CATALINA_OPTS="-server -Xmx2G -XX:+UseConcMarkSweepGC -XX:NewSize=256m -XX:MaxNewSize=256m -XX:PermSize=256m -XX:MaxPermSize=256m -XX:+CMSClassUnloadingEnabled -XX:+CMSPermGenSweepingEnabled -Dfile.encoding=UTF-8"

#Webapp
rm -rf /node/webapps/ROOT/*
rm -rf /node/temp/*
unzip /deploy/*.war -d /node/webapps/ROOT/
